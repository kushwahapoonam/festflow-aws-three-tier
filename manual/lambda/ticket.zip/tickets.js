'use strict';

// FestFlow ticket Lambda. See app/tickets.js for the application code.
const { consume } = require('./app/tickets.js');

exports.consume = consume;
