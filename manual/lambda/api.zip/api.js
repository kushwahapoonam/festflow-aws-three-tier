'use strict';

// FestFlow api Lambda. See app/api.js for the application code.
const { handler } = require('./app/api.js');

exports.handler = handler;
