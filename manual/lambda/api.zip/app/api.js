"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key2 of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key2) && key2 !== except)
        __defProp(to, key2, { get: () => from[key2], enumerable: !(desc = __getOwnPropDesc(from, key2)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// FestFlow-Simulation-Lambdas/source/src/api.ts
var api_exports = {};
__export(api_exports, {
  handler: () => handler,
  respond: () => respond
});
module.exports = __toCommonJS(api_exports);
var import_booking = require("./booking.js");
var import_db = require("./db.js");
var import_catalog = require("./catalog.js");
var import_types = require("./types.js");
var import_tickets = require("./tickets.js");
var roles = ["venue", "kitchen", "admin"];
async function actorFrom(claims = {}) {
  const { sub } = claims;
  (0, import_types.demand)(typeof sub === "string" && claims.token_use === "access", 401, "AUTH_REQUIRED", "Sign in to continue.");
  const groupClaim = claims["cognito:groups"];
  const groups = Array.isArray(groupClaim) ? groupClaim : String(groupClaim ?? "").replace(/[[\]"']/g, "").split(/[\s,]+/);
  const operatorRole = roles.find((role) => groups.includes(role));
  if (groups.includes("admin")) return { sub, role: "admin", scopes: [] };
  if (operatorRole) {
    const assignment = await (0, import_db.get)("OP#" + sub);
    (0, import_types.demand)(assignment && assignment.role === operatorRole, 403, "NO_ASSIGNMENT", "An administrator must assign your work locations.");
    return { sub, ...assignment };
  }
  return { sub, role: "customer", scopes: [] };
}
function permit(actor, role, scope) {
  (0, import_types.demand)(actor.role === role && (!scope || actor.scopes.includes(scope)), 403, "FORBIDDEN", "Your account does not have access to this operation or location.");
}
var slug = (value) => typeof value === "string" && /^[a-zA-Z0-9_-]{1,80}$/.test(value);
var strings = (value, max) => Array.isArray(value) && value.length <= max && value.every(slug) && new Set(value).size === value.length;
function foodInput(value) {
  if (value === void 0) return;
  (0, import_types.demand)(value && typeof value === "object", 400, "INVALID_FOOD", "Choose a kitchen, window and food items.");
  const { kitchenId, slotId, items } = value;
  (0, import_types.demand)(slug(kitchenId) && slug(slotId) && Array.isArray(items) && items.length > 0 && items.length <= 6 && items.every((i) => i && slug(i.id) && Number.isInteger(i.qty) && i.qty >= 1 && i.qty <= 6) && new Set(items.map((i) => i.id)).size === items.length, 400, "INVALID_FOOD", "Choose a valid kitchen, window and food quantities.");
  return { kitchenId, slotId, items: items.map(({ id, qty }) => ({ id, qty })) };
}
async function route(method, path, raw, claims) {
  const match = /^\/api\/([a-z-]+)(?:\/([^/]+))?(?:\/([a-z-]+))?(?:\/([^/]+))?(?:\/([a-z-]+)\/([^/]+))?$/.exec(path);
  (0, import_types.demand)(match, 404, "NOT_FOUND", "Route was not found.");
  const [, group, id, action, subject, leaf, seat] = match;
  if (method === "GET" && path === "/api/events") return { data: await (0, import_catalog.screenings)() };
  if (method === "GET" && group === "shows" && id && action === "availability" && !subject) return { data: await (0, import_booking.availability)(id) };
  const actor = await actorFrom(claims);
  let body = {};
  if (!["GET", "HEAD"].includes(method)) {
    try {
      body = JSON.parse(raw || "{}");
    } catch {
      throw new import_types.Problem(400, "INVALID_JSON", "Send a valid JSON object.");
    }
    (0, import_types.demand)(body && typeof body === "object" && !Array.isArray(body), 400, "INVALID_JSON", "Send a JSON object.");
  }
  if (method === "GET" && path === "/api/me") return { data: { ...actor, paymentMode: "simulation" } };
  if (method === "POST" && path === "/api/holds") {
    permit(actor, "customer");
    const { requestId, showId, seats, food } = body;
    (0, import_types.demand)(slug(requestId) && slug(showId) && strings(seats, 6) && seats.length > 0, 400, "INVALID_HOLD", "Choose one to six distinct seats and include a checkout key.");
    return { data: (0, import_booking.publicBooking)(await (0, import_booking.hold)(actor, { requestId, showId, seats, food: foodInput(food) })) };
  }
  if (group === "bookings" && !subject) {
    permit(actor, "customer");
    if (method === "GET" && !id) return { data: await (0, import_booking.history)(actor) };
    if (method === "GET" && id && !action) return { data: (0, import_booking.publicBooking)(await (0, import_booking.owned)(actor, id)) };
    if (method === "POST" && id && action === "payment") {
      const { attemptId, scenario } = body;
      (0, import_types.demand)(slug(attemptId) && (scenario === "approve" || scenario === "decline"), 400, "INVALID_PAYMENT", "Choose a payment simulation and include an attempt key.");
      return { data: await (0, import_booking.pay)(actor, id, attemptId, scenario) };
    }
    if (method === "POST" && id && action === "cancel") return { data: (0, import_booking.publicBooking)(await (0, import_booking.cancel)(actor, id)) };
    if (method === "GET" && id && action === "ticket") {
      const row = await (0, import_booking.owned)(actor, id);
      (0, import_types.demand)(row.status === "CONFIRMED" && row.ticket === "READY", 409, "TICKET_UNAVAILABLE", "A downloadable ticket is not available yet.");
      return { data: await (0, import_tickets.ticketLink)(id) };
    }
  }
  if (group === "venue" && id) {
    permit(actor, "venue", id);
    if (method === "GET" && action === "bookings" && !subject) {
      const rows = await (0, import_db.query)("VENUE#" + id, void 0, "Venue", 100);
      return { data: { bookings: rows.filter((row) => row.venue === id).map(import_booking.publicBooking), shows: (await (0, import_catalog.screenings)()).filter((s) => s.venue === id) } };
    }
    if (method === "POST" && action === "check-in" && !subject) {
      (0, import_types.demand)(typeof body.code === "string" && body.code.length <= 100, 400, "INVALID_TICKET", "Scan or paste a ticket code.");
      return { data: await (0, import_booking.checkIn)(actor, id, body.code) };
    }
    if (method === "PATCH" && action === "shows" && subject) {
      (0, import_types.demand)((await (0, import_catalog.show)(subject))?.venue === id, 403, "FORBIDDEN", "The screening is not assigned to this venue.");
      if (leaf === "seats" && seat) {
        (0, import_types.demand)(typeof body.blocked === "boolean", 400, "INVALID_SEAT", "Send a blocked flag.");
        const ok = await (0, import_db.commit)([(0, import_db.update)(
          (0, import_db.key)("SHOW#" + subject, "SEAT#" + seat),
          "SET blocked = :flag",
          "attribute_exists(pk) AND attribute_not_exists(booking)",
          { ":flag": body.blocked }
        ), (0, import_booking.audit)(actor.sub, "SEAT_UPDATED", subject + "/" + seat)]);
        (0, import_types.demand)(ok, 409, "SEAT_IN_USE", "The seat is reserved or does not exist.");
      } else if (!leaf) {
        const { open, startsAt } = body;
        (0, import_types.demand)(open !== void 0 || startsAt !== void 0, 400, "INVALID_SHOW", "Supply a booking flag or a future showtime.");
        const values = { ":v": id };
        const names = {};
        const fields = [];
        let condition = "venue = :v";
        if (open !== void 0) {
          (0, import_types.demand)(typeof open === "boolean", 400, "INVALID_SHOW", "The booking flag must be true or false.");
          fields.push("#open = :o");
          values[":o"] = open;
          names["#open"] = "open";
        }
        if (startsAt !== void 0) {
          (0, import_types.demand)(typeof startsAt === "string" && /^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{1,3})?(?:Z|[+-]\d\d:\d\d)$/.test(startsAt) && Date.parse(startsAt) > Date.now(), 400, "INVALID_SHOW", "Provide a future ISO timestamp with an offset.");
          fields.push("startsAt = :s");
          values[":s"] = (0, import_booking.timestamp)(Date.parse(startsAt));
          condition += " AND attribute_not_exists(bookingCount)";
        }
        const ok = await (0, import_db.commit)([(0, import_db.update)(
          (0, import_db.key)("FESTIVAL", "SHOW#" + subject),
          "SET " + fields.join(", "),
          condition,
          values,
          Object.keys(names).length ? names : void 0
        ), (0, import_booking.audit)(actor.sub, "SHOW_UPDATED", subject)]);
        (0, import_types.demand)(ok, 409, "SHOW_HAS_BOOKINGS", "The showtime is fixed once a booking has been created.");
      } else throw new import_types.Problem(404, "NOT_FOUND", "Route was not found.");
      return { data: { ok: true } };
    }
  }
  if (group === "kitchen" && id && action === "orders") {
    permit(actor, "kitchen", id);
    if (method === "GET" && !subject) {
      const indexed = await (0, import_db.query)("KITCHEN#" + id, void 0, "Kitchen", 100);
      const latest = await Promise.all(indexed.map((r) => (0, import_booking.booking)(r.id)));
      return { data: { windows: await (0, import_catalog.slots)(id), orders: latest.flatMap((r) => r?.status === "CONFIRMED" && r.food?.kitchenId === id ? [(0, import_booking.publicBooking)(r)] : []) } };
    }
    if (method === "PATCH" && subject && !leaf) {
      const { status } = body;
      (0, import_types.demand)(status === "PREPARING" || status === "READY" || status === "COLLECTED", 400, "INVALID_PREP", "Choose a valid kitchen status.");
      return { data: await (0, import_booking.prepare)(actor, id, subject, status) };
    }
  }
  if (group === "admin") {
    permit(actor, "admin");
    if (method === "GET" && path === "/api/admin/audit") {
      return { data: await (0, import_db.query)("AUDIT#ALL", void 0, void 0, 100, true) };
    }
  }
  throw new import_types.Problem(404, "NOT_FOUND", "Route was not found.");
}
async function assign(method, path, raw, claims) {
  const match = /^\/api\/admin\/operators\/([0-9a-f-]{36})$/.exec(path);
  if (!match || method !== "PUT") return route(method, path, raw, claims);
  const actor = await actorFrom(claims);
  permit(actor, "admin");
  let body;
  try {
    body = JSON.parse(raw);
  } catch {
    throw new import_types.Problem(400, "INVALID_JSON", "Send a valid JSON object.");
  }
  const { role, scopes } = body ?? {};
  (0, import_types.demand)((role === "venue" || role === "kitchen" || role === "none") && strings(scopes, 10) && (role === "none" ? scopes.length === 0 : scopes.length > 0), 400, "INVALID_ASSIGNMENT", "Supply an operator role and valid scope list.");
  const venues = new Set((await (0, import_catalog.screenings)()).map((s) => s.venue));
  for (const location of scopes) {
    (0, import_types.demand)(role === "venue" ? venues.has(location) : await (0, import_catalog.kitchen)(location), 400, "UNKNOWN_SCOPE", "A selected scope does not exist.");
  }
  const target = match[1];
  await (0, import_db.commit)([{
    ...(0, import_db.update)(
      (0, import_db.key)("OP#" + target),
      "SET #role = :role, scopes = :scopes",
      "attribute_not_exists(pk) OR attribute_exists(pk)",
      { ":role": role, ":scopes": scopes },
      { "#role": "role" }
    )
  }, (0, import_booking.audit)(actor.sub, "OPERATOR_ASSIGNMENT_CHANGED", target)]);
  return { data: { role, scopes } };
}
async function respond(method, path, raw, claims, requestId) {
  let statusCode = 200;
  let data;
  let code = "OK";
  try {
    (0, import_types.demand)(raw.length <= 12e3, 413, "BODY_TOO_LARGE", "The request is too large.");
    const result = await assign(method, path, raw, claims);
    data = result.data;
    statusCode = result.status ?? 200;
  } catch (error) {
    statusCode = error instanceof import_types.Problem ? error.status : 500;
    code = error instanceof import_types.Problem ? error.code : "INTERNAL";
    if (statusCode === 500) console.error(JSON.stringify({ event: "api_error", requestId, errorType: error.name }));
    data = { error: code, message: error instanceof import_types.Problem ? error.message : "FestFlow could not complete the request. Try again.", requestId };
  }
  console.log(JSON.stringify({ event: "api", requestId, method, route: path.split("/")[2], status: statusCode, code }));
  return { statusCode, headers: { "content-type": "application/json", "cache-control": "no-store", "x-request-id": requestId }, body: JSON.stringify(data) };
}
async function handler(event) {
  return respond(
    event.requestContext.http.method,
    event.rawPath,
    event.isBase64Encoded ? Buffer.from(event.body ?? "", "base64").toString() : event.body ?? "",
    event.requestContext.authorizer?.jwt?.claims,
    event.requestContext.requestId
  );
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler,
  respond
});
