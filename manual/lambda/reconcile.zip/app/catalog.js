"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key2 of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key2) && key2 !== except)
        __defProp(to, key2, { get: () => from[key2], enumerable: !(desc = __getOwnPropDesc(from, key2)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// FestFlow-Simulation-Lambdas/source/src/catalog.ts
var catalog_exports = {};
__export(catalog_exports, {
  kitchen: () => kitchen,
  kitchens: () => kitchens,
  screenings: () => screenings,
  seats: () => seats,
  seed: () => seed,
  show: () => show,
  slots: () => slots
});
module.exports = __toCommonJS(catalog_exports);
var import_db = require("./db.js");
var screenings = () => (0, import_db.query)("FESTIVAL", { prefix: "SHOW#" });
var show = (id) => (0, import_db.get)("FESTIVAL", "SHOW#" + id);
var seats = (id) => (0, import_db.query)("SHOW#" + id, { prefix: "SEAT#" });
var kitchens = () => (0, import_db.query)("FESTIVAL", { prefix: "KITCHEN#" });
var kitchen = (id) => (0, import_db.get)("FESTIVAL", "KITCHEN#" + id);
var slots = (id) => (0, import_db.query)("KITCHEN#" + id, { prefix: "SLOT#" });
async function seed(now = Date.now()) {
  const date = new Date(now + 7 * 864e5).toISOString().slice(0, 10);
  const at = (time) => date + "T" + time + ":00.000Z";
  const shows = [
    { id: "monsoon", venue: "banyan", venueName: "Banyan Courtyard", title: "The Monsoon Cut", note: "A Bengaluru sound recordist follows the first rain through a city that never goes quiet.", genre: "Independent cinema", startsAt: at("12:30"), open: true, price: 320, art: "rain" },
    { id: "orbit", venue: "silk", venueName: "Silk Mill Studio", title: "Between Orbits", note: "Three strangers meet on the last bus before a lunar eclipse.", genre: "Science fiction", startsAt: at("13:30"), open: true, price: 280, art: "moon" },
    { id: "afterlight", venue: "banyan", venueName: "Banyan Courtyard", title: "Afterlight", note: "Short films about the city after the shops close.", genre: "Short film collection", startsAt: at("15:00"), open: true, price: 250, art: "sun" },
    { id: "last-call", venue: "silk", venueName: "Silk Mill Studio", title: "Last Call", note: "A trio of midnight comedies from local filmmakers.", genre: "Comedy shorts", startsAt: at("16:30"), open: true, price: 250, art: "moon" }
  ];
  const menus = [
    { id: "curry", name: "Curry Leaf Counter", venue: "banyan", menu: [{ id: "bun", name: "Ghee podi bun", price: 120, detail: "Chilli, curry leaf and jaggery butter" }, { id: "lime", name: "Salted lime soda", price: 80, detail: "Fresh lime and black salt" }] },
    { id: "tiffin", name: "The Tiffin Window", venue: "silk", menu: [{ id: "puff", name: "Pepper mushroom puff", price: 140, detail: "Flaky pastry and cracked pepper" }, { id: "coffee", name: "Cold filter coffee", price: 100, detail: "Chicory blend over ice" }] }
  ];
  for (const s of shows) {
    await (0, import_db.insertOnce)({ ...(0, import_db.key)("FESTIVAL", "SHOW#" + s.id), ...s });
    const ids = s.id === "last-call" ? ["A1"] : ["A", "B", "C", "D"].flatMap((row) => [1, 2, 3, 4, 5, 6].map((n) => row + n));
    for (const id of ids) await (0, import_db.insertOnce)({ ...(0, import_db.key)("SHOW#" + s.id, "SEAT#" + id), id });
  }
  for (const k of menus) {
    await (0, import_db.insertOnce)({ ...(0, import_db.key)("FESTIVAL", "KITCHEN#" + k.id), ...k });
    const times = k.id === "curry" ? ["11:45", "12:00", "14:30"] : ["12:45", "13:00", "16:00"];
    for (const [i, time] of times.entries()) {
      const id = "window-" + (i + 1);
      await (0, import_db.insertOnce)({ ...(0, import_db.key)("KITCHEN#" + k.id, "SLOT#" + id), id, at: at(time), used: 0, capacity: i === 2 ? 1 : 6 });
    }
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  kitchen,
  kitchens,
  screenings,
  seats,
  seed,
  show,
  slots
});
