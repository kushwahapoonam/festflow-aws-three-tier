"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key2 of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key2) && key2 !== except)
        __defProp(to, key2, { get: () => from[key2], enumerable: !(desc = __getOwnPropDesc(from, key2)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// FestFlow-Simulation-Lambdas/source/src/booking.ts
var booking_exports = {};
__export(booking_exports, {
  audit: () => audit,
  availability: () => availability,
  booking: () => booking,
  cancel: () => cancel,
  checkIn: () => checkIn,
  expire: () => expire,
  history: () => history,
  hold: () => hold,
  owned: () => owned,
  pay: () => pay,
  prepare: () => prepare,
  publicBooking: () => publicBooking,
  ticketCode: () => ticketCode,
  timestamp: () => timestamp,
  workKey: () => workKey
});
module.exports = __toCommonJS(booking_exports);
var import_node_crypto = require("node:crypto");
var import_db = require("./db.js");
var import_catalog = require("./catalog.js");
var import_types = require("./types.js");
var timestamp = (now = Date.now()) => new Date(now).toISOString();
var workKey = (date, id) => date + "#" + id;
var encode = (value) => (0, import_node_crypto.createHash)("sha256").update(JSON.stringify(value)).digest("hex");
var booking = (id) => (0, import_db.get)("BOOK#" + id);
function publicBooking(row) {
  const { id, showId, venue, title, startsAt, seats, food, pickupAt, dishes, total, expiresAt, createdAt, status, ticket, prep, checkedAt } = row;
  return { id, showId, venue, title, startsAt, seats, food, pickupAt, dishes, total, expiresAt, createdAt, status, ticket, prep, checkedAt };
}
async function owned(actor, id) {
  const row = await booking(id);
  (0, import_types.demand)(row, 404, "NOT_FOUND", "Booking was not found.");
  (0, import_types.demand)(row.owner === actor.sub, 403, "FORBIDDEN", "This booking belongs to another customer.");
  return row;
}
function audit(actor, event, target, at = timestamp()) {
  return (0, import_db.put)({ ...(0, import_db.key)("AUDIT#ALL", workKey(at, (0, import_node_crypto.randomUUID)())), actor, event, target, at });
}
async function availability(id) {
  const [screening, rows, menus] = await Promise.all([
    (0, import_catalog.show)(id),
    (0, import_db.query)("SHOW#" + id, { prefix: "SEAT#" }),
    (0, import_catalog.kitchens)()
  ]);
  (0, import_types.demand)(screening, 404, "NOT_FOUND", "Screening was not found.");
  return {
    screening,
    seats: rows.map(({ id: id2, booking: booking2, blocked }) => ({ id: id2, available: !booking2 && !blocked, blocked: !!blocked })),
    kitchens: await Promise.all(menus.filter((k) => k.venue === screening.venue).map(async (k) => ({
      ...k,
      slots: (await (0, import_catalog.slots)(k.id)).filter((s) => s.at <= screening.startsAt && s.at > timestamp()).map((s) => ({ ...s, remaining: s.capacity - s.used }))
    })))
  };
}
async function hold(actor, input, now = Date.now()) {
  const id = encode([actor.sub, input.requestId]).slice(0, 32);
  const pk = "BOOK#" + id;
  const seatIds = [...input.seats].sort();
  const food = input.food && { ...input.food, items: [...input.food.items].sort((a, b) => a.id.localeCompare(b.id)) };
  const fingerprint = encode([input.showId, seatIds, food]);
  const prior = await booking(id);
  if (prior) {
    (0, import_types.demand)(prior.fingerprint === fingerprint, 409, "IDEMPOTENCY_MISMATCH", "Use a new checkout key after changing your selection.");
    return prior;
  }
  const at = timestamp(now);
  const screening = await (0, import_catalog.show)(input.showId);
  (0, import_types.demand)(screening?.open && screening.startsAt > at, 409, "SHOW_CLOSED", "This screening is closed to new bookings.");
  let price = screening.price * seatIds.length;
  let units = 0;
  let pickupAt;
  const dishes = [];
  let ends = Date.parse(screening.startsAt);
  const extra = [];
  if (food) {
    const [menu, slot] = await Promise.all([(0, import_catalog.kitchen)(food.kitchenId), (0, import_db.get)("KITCHEN#" + food.kitchenId, "SLOT#" + food.slotId)]);
    (0, import_types.demand)(menu?.venue === screening.venue && slot && slot.at <= screening.startsAt && slot.at > at, 400, "INVALID_PICKUP", "Choose a valid pickup window at this venue.");
    for (const item of food.items) {
      const dish = menu.menu.find((d) => d.id === item.id);
      (0, import_types.demand)(dish, 400, "INVALID_DISH", "Choose dishes from the selected kitchen.");
      dishes.push({ name: dish.name, qty: item.qty });
      units += item.qty;
      price += dish.price * item.qty;
    }
    (0, import_types.demand)(units > 0 && units <= 6, 400, "INVALID_QUANTITY", "Choose one to six food items.");
    pickupAt = slot.at;
    ends = Math.min(ends, Date.parse(slot.at));
    extra.push((0, import_db.update)(
      (0, import_db.key)("KITCHEN#" + food.kitchenId, "SLOT#" + food.slotId),
      "ADD #used :units",
      "#used <= :free AND #capacity = :capacity AND #at = :slotAt",
      { ":units": units, ":free": slot.capacity - units, ":capacity": slot.capacity, ":slotAt": slot.at },
      { "#at": "at", "#used": "used", "#capacity": "capacity" }
    ));
  }
  const expiresAt = timestamp(Math.min(ends, now + 1e3 * Number(process.env.HOLD_SECONDS ?? 120)));
  const row = {
    ...(0, import_db.key)(pk),
    id,
    owner: actor.sub,
    showId: screening.id,
    venue: screening.venue,
    title: screening.title,
    startsAt: screening.startsAt,
    seats: seatIds,
    food,
    pickupAt,
    dishes: food ? dishes : void 0,
    units,
    total: price,
    fingerprint,
    expiresAt,
    createdAt: at,
    status: "HELD",
    qrSecret: (0, import_node_crypto.randomUUID)()
  };
  const ok = await (0, import_db.commit)([
    (0, import_db.update)(
      (0, import_db.key)("FESTIVAL", "SHOW#" + screening.id),
      "ADD bookingCount :one",
      "#open = :true AND startsAt = :start",
      { ":one": 1, ":true": true, ":start": screening.startsAt },
      { "#open": "open" }
    ),
    ...seatIds.map((seat) => (0, import_db.update)(
      (0, import_db.key)("SHOW#" + screening.id, "SEAT#" + seat),
      "SET booking = :id",
      "attribute_exists(pk) AND attribute_not_exists(booking) AND (attribute_not_exists(blocked) OR blocked = :off)",
      { ":id": id, ":off": false }
    )),
    ...extra,
    (0, import_db.put)({ ...row, gpk: "DUE", gsk: workKey(expiresAt, id), vpk: "VENUE#" + row.venue, vsk: workKey(at, id) }),
    (0, import_db.put)({ ...(0, import_db.key)(pk, "OWNER"), gpk: "OWNER#" + actor.sub, gsk: workKey(at, id), id }),
    audit(actor.sub, "HOLD_CREATED", id, at)
  ]);
  if (ok) return row;
  const winner = await booking(id);
  if (winner) {
    (0, import_types.demand)(winner.fingerprint === fingerprint, 409, "IDEMPOTENCY_MISMATCH", "Use a new checkout key after changing your selection.");
    return winner;
  }
  (0, import_types.demand)(false, 409, "INVENTORY_CONFLICT", "A seat or pickup window changed. Review live availability and try again.");
}
async function history(actor) {
  const pointers = await (0, import_db.query)("OWNER#" + actor.sub, void 0, "Lookup", 100, true);
  const rows = await Promise.all(pointers.map((p) => booking(p.id)));
  return rows.flatMap((row) => row && row.owner === actor.sub ? [publicBooking(row)] : []);
}
function release(row) {
  const writes = row.seats.map((seat) => (0, import_db.update)(
    (0, import_db.key)("SHOW#" + row.showId, "SEAT#" + seat),
    "REMOVE booking",
    "booking = :id",
    { ":id": row.id }
  ));
  if (row.food) writes.push((0, import_db.update)(
    (0, import_db.key)("KITCHEN#" + row.food.kitchenId, "SLOT#" + row.food.slotId),
    "ADD #used :negative",
    "#used >= :units",
    { ":negative": -row.units, ":units": row.units },
    { "#used": "used" }
  ));
  return writes;
}
async function expire(row, now = Date.now()) {
  const at = timestamp(now);
  return await (0, import_db.commit)([
    (0, import_db.update)(
      (0, import_db.key)(row.pk),
      "SET #status = :expired REMOVE gpk, gsk",
      "#status = :held AND expiresAt <= :now",
      { ":expired": "EXPIRED", ":held": "HELD", ":now": at },
      { "#status": "status" }
    ),
    ...release(row),
    audit("system", "HOLD_EXPIRED", row.id, at)
  ]);
}
async function cancel(actor, id, now = Date.now()) {
  const row = await owned(actor, id);
  if (row.status === "CANCELLED") return row;
  const at = timestamp(now);
  const ok = await (0, import_db.commit)([
    (0, import_db.update)(
      (0, import_db.key)(row.pk),
      "SET #status = :cancelled REMOVE gpk, gsk, kpk, ksk",
      "(#status = :held AND expiresAt > :now) OR (#status = :confirmed AND startsAt > :now AND attribute_not_exists(checkedAt) AND (attribute_not_exists(prep) OR prep = :queued))",
      { ":cancelled": "CANCELLED", ":held": "HELD", ":confirmed": "CONFIRMED", ":now": at, ":queued": "QUEUED" },
      { "#status": "status" }
    ),
    ...release(row),
    audit(actor.sub, "BOOKING_CANCELLED", id, at)
  ]);
  const fresh = await owned(actor, id);
  (0, import_types.demand)(ok || fresh.status === "CANCELLED", 409, "CANNOT_CANCEL", "This booking can no longer be cancelled.");
  return fresh;
}
async function pay(actor, id, attemptId, scenario, now) {
  const row = await owned(actor, id);
  const sk = "PAY#" + attemptId;
  const existing = async () => {
    const receipt = await (0, import_db.get)(row.pk, sk);
    if (!receipt) return void 0;
    (0, import_types.demand)(receipt.scenario === scenario, 409, "IDEMPOTENCY_MISMATCH", "This payment key was used with a different scenario.");
    return { outcome: receipt.outcome, booking: publicBooking(await owned(actor, id)) };
  };
  const previous = await existing();
  if (previous) return previous;
  const at = timestamp(now);
  const approved = scenario === "approve";
  const outcome = approved ? "APPROVED" : "DECLINED";
  const condition = "#status = :held AND expiresAt > :now";
  const values = { ":held": "HELD", ":now": at };
  const writes = [(0, import_db.put)({ ...(0, import_db.key)(row.pk, sk), scenario, outcome, at }), audit(actor.sub, "PAYMENT_" + outcome, id, at)];
  if (approved) {
    const foodValues = row.food ? { ":prep": "QUEUED", ":kp": "KITCHEN#" + row.food.kitchenId, ":ks": row.food.slotId + "#" + at + "#" + id } : {};
    const foodUpdate = row.food ? ", prep = :prep, kpk = :kp, ksk = :ks" : "";
    writes.push((0, import_db.update)(
      (0, import_db.key)(row.pk),
      "SET #status = :confirmed, ticket = :pending" + foodUpdate + " REMOVE gpk, gsk",
      condition,
      { ...values, ":confirmed": "CONFIRMED", ":pending": "PENDING", ...foodValues },
      { "#status": "status" }
    ));
    writes.push((0, import_db.put)({ ...(0, import_db.key)(row.pk, "OUTBOX"), id, gpk: "OUTBOX", gsk: workKey(at, id), createdAt: at }));
  } else {
    writes.push({ ConditionCheck: {
      TableName: import_db.table,
      Key: (0, import_db.key)(row.pk),
      ConditionExpression: condition,
      ExpressionAttributeNames: { "#status": "status" },
      ExpressionAttributeValues: values
    } });
  }
  if (await (0, import_db.commit)(writes)) return { outcome, booking: publicBooking(await owned(actor, id)) };
  const duplicate = await existing();
  if (duplicate) return duplicate;
  (0, import_types.demand)(false, 409, "PAYMENT_WINDOW_CLOSED", "This hold has expired or was already settled. View your booking for its current status.");
}
var ticketCode = (row) => "FF1." + row.id + "." + row.qrSecret;
async function checkIn(actor, venue, code, now = Date.now()) {
  const match = /^FF1\.([a-f0-9]{32})\.([a-f0-9-]{36})$/.exec(code);
  (0, import_types.demand)(match, 400, "INVALID_TICKET", "Scan or paste a valid FestFlow ticket.");
  const row = await booking(match[1]);
  (0, import_types.demand)(row, 404, "NOT_FOUND", "Ticket was not found.");
  (0, import_types.demand)(row.venue === venue, 403, "WRONG_VENUE", "This ticket is for another venue.");
  (0, import_types.demand)((0, import_node_crypto.timingSafeEqual)(Buffer.from(match[2]), Buffer.from(row.qrSecret)), 404, "NOT_FOUND", "Ticket was not found.");
  const at = timestamp(now);
  const ok = await (0, import_db.commit)([
    (0, import_db.update)(
      (0, import_db.key)(row.pk),
      "SET checkedAt = :now",
      "#status = :confirmed AND attribute_not_exists(checkedAt)",
      { ":now": at, ":confirmed": "CONFIRMED" },
      { "#status": "status" }
    ),
    audit(actor.sub, "TICKET_CHECKED_IN", row.id, at)
  ]);
  (0, import_types.demand)(ok, 409, "CHECK_IN_CONFLICT", "This booking has been cancelled or already checked in.");
  return { id: row.id, checkedAt: at };
}
async function prepare(actor, kitchenId, id, status) {
  const row = await booking(id);
  (0, import_types.demand)(row, 404, "NOT_FOUND", "Booking was not found.");
  (0, import_types.demand)(row.food?.kitchenId === kitchenId, 403, "FORBIDDEN", "This order belongs to another kitchen.");
  if (row.prep === status && row.status === "CONFIRMED") return publicBooking(row);
  const previous = { QUEUED: "", PREPARING: "QUEUED", READY: "PREPARING", COLLECTED: "READY" }[status];
  const ok = await (0, import_db.commit)([
    (0, import_db.update)(
      (0, import_db.key)(row.pk),
      "SET prep = :next",
      "#status = :confirmed AND prep = :previous",
      { ":next": status, ":confirmed": "CONFIRMED", ":previous": previous },
      { "#status": "status" }
    ),
    audit(actor.sub, "KITCHEN_" + status, id)
  ]);
  (0, import_types.demand)(ok, 409, "ORDER_CHANGED", "Refresh the order before changing its status.");
  return publicBooking(await booking(id));
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  audit,
  availability,
  booking,
  cancel,
  checkIn,
  expire,
  history,
  hold,
  owned,
  pay,
  prepare,
  publicBooking,
  ticketCode,
  timestamp,
  workKey
});
