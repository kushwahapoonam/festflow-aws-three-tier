"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key2 of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key2) && key2 !== except)
        __defProp(to, key2, { get: () => from[key2], enumerable: !(desc = __getOwnPropDesc(from, key2)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// vendor:@aws-sdk/client-dynamodb
var require_client_dynamodb = __commonJS({
  "vendor:@aws-sdk/client-dynamodb"(exports2, module2) {
    module2.exports = require("./vendor.js")["@aws-sdk/client-dynamodb"];
  }
});

// vendor:@aws-sdk/lib-dynamodb
var require_lib_dynamodb = __commonJS({
  "vendor:@aws-sdk/lib-dynamodb"(exports2, module2) {
    module2.exports = require("./vendor.js")["@aws-sdk/lib-dynamodb"];
  }
});

// FestFlow-Simulation-Lambdas/source/src/db.ts
var db_exports = {};
__export(db_exports, {
  commit: () => commit,
  createLocalTable: () => createLocalTable,
  get: () => get,
  insertOnce: () => insertOnce,
  key: () => key,
  put: () => put,
  query: () => query,
  table: () => table,
  update: () => update
});
module.exports = __toCommonJS(db_exports);
var import_client_dynamodb = __toESM(require_client_dynamodb(), 1);
var import_lib_dynamodb = __toESM(require_lib_dynamodb(), 1);
var table = process.env.TABLE_NAME ?? "festflow-local";
var endpoint = process.env.DDB_ENDPOINT;
var client = new import_client_dynamodb.DynamoDBClient(endpoint ? {
  endpoint,
  region: "us-east-1",
  credentials: { accessKeyId: "local", secretAccessKey: "local" }
} : {});
var db = import_lib_dynamodb.DynamoDBDocumentClient.from(client, { marshallOptions: { removeUndefinedValues: true } });
var key = (pk, sk = "META") => ({ pk, sk });
var get = async (pk, sk = "META") => (await db.send(new import_lib_dynamodb.GetCommand({ TableName: table, Key: key(pk, sk), ConsistentRead: true }))).Item;
async function query(pk, sort, index, max = Infinity, newest = false) {
  const attributes = index === "Lookup" ? ["gpk", "gsk"] : index === "Venue" ? ["vpk", "vsk"] : index === "Kitchen" ? ["kpk", "ksk"] : ["pk", "sk"];
  let expression = "#p = :p";
  const names = { "#p": attributes[0] };
  const values = { ":p": pk };
  if (sort) {
    names["#s"] = attributes[1];
    values[":s"] = "prefix" in sort ? sort.prefix : sort.through;
    expression += "prefix" in sort ? " AND begins_with(#s, :s)" : " AND #s <= :s";
  }
  const items = [];
  let cursor;
  do {
    const page = await db.send(new import_lib_dynamodb.QueryCommand({
      TableName: table,
      IndexName: index,
      ConsistentRead: !index,
      ScanIndexForward: !newest,
      KeyConditionExpression: expression,
      ExpressionAttributeNames: names,
      ExpressionAttributeValues: values,
      ExclusiveStartKey: cursor,
      Limit: Number.isFinite(max) ? max - items.length : void 0
    }));
    items.push(...page.Items ?? []);
    cursor = page.LastEvaluatedKey;
  } while (cursor && items.length < max);
  return items;
}
async function insertOnce(item) {
  try {
    await db.send(new import_lib_dynamodb.PutCommand({ TableName: table, Item: item, ConditionExpression: "attribute_not_exists(pk)" }));
  } catch (error) {
    if (!(error instanceof Error) || error.name !== "ConditionalCheckFailedException") throw error;
  }
}
function put(item) {
  return { Put: { TableName: table, Item: item, ConditionExpression: "attribute_not_exists(pk)" } };
}
function update(Key, UpdateExpression, ConditionExpression, ExpressionAttributeValues, ExpressionAttributeNames) {
  return { Update: { TableName: table, Key, UpdateExpression, ConditionExpression, ExpressionAttributeValues, ExpressionAttributeNames } };
}
async function commit(items) {
  for (let attempt = 0; ; attempt++) {
    try {
      await db.send(new import_lib_dynamodb.TransactWriteCommand({ TransactItems: items }));
      return true;
    } catch (error) {
      if (!(error instanceof Error)) throw error;
      if (error.name === "TransactionCanceledException" && "CancellationReasons" in error) {
        const reasons = error.CancellationReasons;
        if (reasons?.some((r) => r.Code === "ConditionalCheckFailed")) return false;
        if (attempt >= 4 || !reasons?.some((r) => r.Code === "TransactionConflict")) throw error;
      } else if (attempt >= 4 || error.name !== "TransactionInProgressException") throw error;
      await new Promise((resolve) => setTimeout(resolve, 20 * (attempt + 1) + Math.random() * 30));
    }
  }
}
async function createLocalTable() {
  if (!endpoint || !/^http:\/\/(localhost|127\.0\.0\.1):\d+$/.test(endpoint)) throw Error("A loopback DynamoDB endpoint is required");
  const indexes = [["Lookup", "gpk", "gsk"], ["Venue", "vpk", "vsk"], ["Kitchen", "kpk", "ksk"]];
  try {
    await client.send(new import_client_dynamodb.CreateTableCommand({
      TableName: table,
      BillingMode: "PAY_PER_REQUEST",
      AttributeDefinitions: ["pk", "sk", ...indexes.flatMap(([, p, s]) => [p, s])].map((AttributeName) => ({ AttributeName, AttributeType: "S" })),
      KeySchema: [{ AttributeName: "pk", KeyType: "HASH" }, { AttributeName: "sk", KeyType: "RANGE" }],
      GlobalSecondaryIndexes: indexes.map(([IndexName, p, s]) => ({ IndexName, KeySchema: [{ AttributeName: p, KeyType: "HASH" }, { AttributeName: s, KeyType: "RANGE" }], Projection: { ProjectionType: "ALL" } }))
    }));
  } catch (error) {
    if (!(error instanceof Error) || error.name !== "ResourceInUseException") throw error;
  }
  await (0, import_client_dynamodb.waitUntilTableExists)({ client, maxWaitTime: 20, minDelay: 1 }, { TableName: table });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  commit,
  createLocalTable,
  get,
  insertOnce,
  key,
  put,
  query,
  table,
  update
});
