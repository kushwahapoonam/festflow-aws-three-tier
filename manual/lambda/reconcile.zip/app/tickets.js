"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key2 of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key2) && key2 !== except)
        __defProp(to, key2, { get: () => from[key2], enumerable: !(desc = __getOwnPropDesc(from, key2)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// vendor:qrcode
var require_qrcode = __commonJS({
  "vendor:qrcode"(exports2, module2) {
    module2.exports = require("./vendor.js")["qrcode"];
  }
});

// vendor:@aws-sdk/client-s3
var require_client_s3 = __commonJS({
  "vendor:@aws-sdk/client-s3"(exports2, module2) {
    module2.exports = require("./vendor.js")["@aws-sdk/client-s3"];
  }
});

// vendor:@aws-sdk/s3-request-presigner
var require_s3_request_presigner = __commonJS({
  "vendor:@aws-sdk/s3-request-presigner"(exports2, module2) {
    module2.exports = require("./vendor.js")["@aws-sdk/s3-request-presigner"];
  }
});

// vendor:@aws-sdk/client-sqs
var require_client_sqs = __commonJS({
  "vendor:@aws-sdk/client-sqs"(exports2, module2) {
    module2.exports = require("./vendor.js")["@aws-sdk/client-sqs"];
  }
});

// FestFlow-Simulation-Lambdas/source/src/tickets.ts
var tickets_exports = {};
__export(tickets_exports, {
  consume: () => consume,
  generateTicket: () => generateTicket,
  reconcile: () => reconcile,
  scheduled: () => scheduled,
  ticketLink: () => ticketLink
});
module.exports = __toCommonJS(tickets_exports);
var import_promises = require("node:fs/promises");
var import_node_path = require("node:path");
var import_qrcode = __toESM(require_qrcode(), 1);
var import_client_s3 = __toESM(require_client_s3(), 1);
var import_s3_request_presigner = __toESM(require_s3_request_presigner(), 1);
var import_client_sqs = __toESM(require_client_sqs(), 1);
var import_booking = require("./booking.js");
var import_db = require("./db.js");
var s3 = new import_client_s3.S3Client({});
var sqs = new import_client_sqs.SQSClient({});
var objectKey = (id) => "tickets/" + id + ".png";
var local = !!process.env.DDB_ENDPOINT;
var fileRoot = process.env.TICKET_DIR ?? ".festflow/tickets";
var eligible = "#status = :confirmed AND ticket IN (:pending, :failed)";
var eligibleValues = { ":confirmed": "CONFIRMED", ":pending": "PENDING", ":failed": "FAILED" };
async function ticketLink(id) {
  const command = new import_client_s3.GetObjectCommand({ Bucket: process.env.TICKET_BUCKET, Key: objectKey(id) });
  if (local) {
    const entry = await (0, import_booking.booking)(id);
    return { url: "data:image/png;base64," + (await (0, import_promises.readFile)((0, import_node_path.join)(fileRoot, id + ".png"))).toString("base64"), code: (0, import_booking.ticketCode)(entry) };
  }
  return { url: await (0, import_s3_request_presigner.getSignedUrl)(s3, command, { expiresIn: 90 }), code: (0, import_booking.ticketCode)(await (0, import_booking.booking)(id)) };
}
async function generateTicket(id, receiveCount = 1, storeOverride) {
  const row = await (0, import_booking.booking)(id);
  if (!row || row.status !== "CONFIRMED" || row.ticket === "READY") return;
  try {
    if (process.env.FAIL_TICKET_ID === id) throw Error("InjectedTicketFailure");
    const image = await import_qrcode.default.toBuffer((0, import_booking.ticketCode)(row), { width: 360, margin: 3, errorCorrectionLevel: "M" });
    if (storeOverride) await storeOverride(id, image);
    else if (local) {
      await (0, import_promises.mkdir)(fileRoot, { recursive: true });
      await (0, import_promises.writeFile)((0, import_node_path.join)(fileRoot, id + ".png"), image);
    } else await s3.send(new import_client_s3.PutObjectCommand({
      Bucket: process.env.TICKET_BUCKET,
      Key: objectKey(id),
      Body: image,
      ContentType: "image/png",
      CacheControl: "private, no-store"
    }));
  } catch (error) {
    if (receiveCount >= 3) await (0, import_db.commit)([
      (0, import_db.update)((0, import_db.key)(row.pk), "SET ticket = :failed", "#status = :confirmed AND ticket = :pending", eligibleValues, { "#status": "status" }),
      (0, import_booking.audit)("system", "TICKET_FAILED", id)
    ]);
    throw error;
  }
  await (0, import_db.commit)([
    (0, import_db.update)((0, import_db.key)(row.pk), "SET ticket = :ready", eligible, { ...eligibleValues, ":ready": "READY" }, { "#status": "status" }),
    (0, import_booking.audit)("system", "TICKET_READY", id)
  ]);
}
async function consume(event) {
  const batchItemFailures = [];
  for (const message of event.Records) {
    try {
      const { id } = JSON.parse(message.body);
      if (typeof id !== "string" || !/^[a-f0-9]{32}$/.test(id)) throw Error("InvalidTicketJob");
      await generateTicket(id, Number(message.attributes.ApproximateReceiveCount));
    } catch (error) {
      console.error(JSON.stringify({ event: "ticket_job_failed", messageId: message.messageId, errorType: error.name }));
      batchItemFailures.push({ itemIdentifier: message.messageId });
    }
  }
  return { batchItemFailures };
}
async function reconcile(now = Date.now()) {
  const at = (0, import_booking.timestamp)(now);
  const due = await (0, import_db.query)("DUE", { through: at + "#~" }, "Lookup", 25);
  let expired = 0;
  for (const row of due) {
    if (await (0, import_booking.expire)(row, now)) expired++;
  }
  const pending = await (0, import_db.query)("OUTBOX", void 0, "Lookup", 25);
  let sent = 0;
  let failures = 0;
  for (const candidate of pending) {
    const job = await (0, import_db.get)(candidate.pk, "OUTBOX");
    if (job?.gpk !== "OUTBOX") continue;
    try {
      if (local) await generateTicket(job.id);
      else await sqs.send(new import_client_sqs.SendMessageCommand({ QueueUrl: process.env.TICKET_QUEUE, MessageBody: JSON.stringify({ id: job.id }) }));
      const marked = await (0, import_db.commit)([(0, import_db.update)(
        (0, import_db.key)(job.pk, "OUTBOX"),
        "SET sentAt = :at REMOVE gpk, gsk",
        "gpk = :pending",
        { ":at": at, ":pending": "OUTBOX" }
      )]);
      if (marked) sent++;
    } catch (error) {
      failures++;
      console.error(JSON.stringify({ event: "outbox_send_failed", bookingId: job.id, errorType: error.name }));
    }
  }
  const result = {
    event: "reconcile",
    expired,
    sent,
    failures,
    expiryLagSeconds: due.length ? Math.max(0, Math.floor((now - Date.parse(due[0].expiresAt)) / 1e3)) : 0
  };
  console.log(JSON.stringify(result));
  return result;
}
async function scheduled() {
  return reconcile();
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  consume,
  generateTicket,
  reconcile,
  scheduled,
  ticketLink
});
