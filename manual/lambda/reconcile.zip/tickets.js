'use strict';

// FestFlow reconcile Lambda. See app/tickets.js for the application code.
const { scheduled } = require('./app/tickets.js');

exports.scheduled = scheduled;
